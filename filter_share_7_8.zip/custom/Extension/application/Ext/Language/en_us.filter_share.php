<?php
$app_strings['LBL_SHARE_BUTTON_LABEL'] = 'Share';